package com.diabloxmj.client;

import net.minecraft.text.Text;

// 1. Si "extends Screen" bloque à cause de class_437, on utilise le chemin complet ou Object
public class MJ_ModMenu_Config extends net.minecraft.client.gui.screen.Screen {

    // 2. On change le type du parent en Object pour éviter le contrôle de class_437
    private final Object parent;

    public MJ_ModMenu_Config(Object parent) {
        // On passe le titre de l'écran au constructeur parent de Minecraft
        super(Text.literal("Configuration de Mon Mod"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();
    }

    @Override
    public void close() {
        // Quand le joueur ferme cet écran, on le renvoie sagement à l'écran parent (Mod Menu)
        if (this.client != null && this.parent instanceof net.minecraft.client.gui.screen.Screen) {
            this.client.setScreen((net.minecraft.client.gui.screen.Screen) this.parent);
        }
    }
}