package com.diabloxmj.client;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import com.diabloxmj.mod.mj_xpbottle.network.MJ_XPBottle_Sync_Payload;
import com.diabloxmj.mod.mj_xpbottle.MJ_XPBottle_Config;

public class MJ_XPBottle_Client {

    public static void init() {
        ClientPlayNetworking.registerGlobalReceiver(MJ_XPBottle_Sync_Payload.ID, (payload, context) -> {
            MJ_XPBottle_Config.INSTANCE.XPBottle_lvl1_Max_Capacity = payload.lvl1Max();
            MJ_XPBottle_Config.INSTANCE.XPBottle_lvl2_Max_Capacity = payload.lvl2Max();
            MJ_XPBottle_Config.INSTANCE.XPBottle_lvl3_Max_Capacity = payload.lvl3Max();
            MJ_XPBottle_Config.INSTANCE.XPBottle_lvl4_Max_Capacity = payload.lvl4Max();
            MJ_XPBottle_Config.INSTANCE.XPBottle_lvl5_Max_Capacity = payload.lvl5Max();
            MJ_XPBottle_Config.INSTANCE.XPBottle_lvl6_Max_Capacity = payload.lvl6Max();
        });
    }
}