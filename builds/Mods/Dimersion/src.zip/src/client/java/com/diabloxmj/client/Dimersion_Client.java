package com.diabloxmj.client;

import com.diabloxmj.core.Dimersion_Config;
import net.fabricmc.api.ClientModInitializer;
import com.diabloxmj.core.api.MJ_SubMod;
import com.diabloxmj.core.Dimersion_Core;

public class Dimersion_Client implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// On reprend la même liste de modules que le Core, et on initialise la partie graphique
		for (MJ_SubMod module : Dimersion_Core.getModules()) { // Pense à faire un getter pour MODULES dans le Core
			if (module.isEnabled()) {
				module.onClientInit(); // Appelle le code de rendu/réseau client du sous-mod
			}
		}
		if (Dimersion_Config.INSTANCE.enable_xpbottle) {
			MJ_XPBottle_Client.init();
		}
	}
}