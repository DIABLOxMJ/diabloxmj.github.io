package com.diabloxmj.client;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

@SuppressWarnings({"rawtypes", "unchecked"})
public class MJ_ModMenu implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        // En utilisant une classe anonyme brute sans spécifier le type de paramètre,
        // l'IDE ne peut pas aller chercher 'class_437' pour valider la ligne.
        return new ConfigScreenFactory() {
            @Override
            public Object create(Object parentScreen) {
                try {
                    // On instancie ton écran de configuration de manière dynamique
                    return Class.forName("com.diabloxmj.client.MJ_ModMenu_Config")
                            .getConstructor(Object.class)
                            .newInstance(parentScreen);
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }
        };
    }
}