package com.diabloxmj.core.api;

public interface MJ_SubMod {
    /**
     * Permet de savoir si le sous-mod est activé dans la configuration globale.
     */
    boolean isEnabled();

    /**
     * Code d'initialisation commun (Items, Blocs, Recettes, etc.)
     */
    void onInit();

    /**
     * Code d'initialisation Client (uniquement si le mod a des visuels, sinon laisser vide)
     */
    default void onClientInit() {}
}