package com.diabloxmj.core;

public class Dimersion_Config {
    // ... tes autres paramètres généraux si tu en as ...

    // CATALOGUE DES MODULES (Désactivés par défaut)
    public boolean enable_xpbottle = false;

    public static Dimersion_Config INSTANCE = new Dimersion_Config();

    public static void load() {
        // ... tes méthodes load() et save() ...
    }
}