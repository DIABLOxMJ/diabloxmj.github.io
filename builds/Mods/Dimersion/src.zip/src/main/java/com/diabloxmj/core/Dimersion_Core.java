package com.diabloxmj.core;

import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import com.diabloxmj.core.api.MJ_SubMod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.ArrayList;

public class Dimersion_Core implements ModInitializer {
	public static final String MOD_ID = "dimersion";
	public static final Logger LOGGER = LoggerFactory.getLogger("Dimersion");
	// La liste qui référence l'intégralité de nos sous-mods présents dans le code
	private static final List<MJ_SubMod> MODULES = new ArrayList<>();

	@Override
	public void onInitialize() {
		// 1. Charger le fichier de configuration JSON (qui contient les true/false)
		Dimersion_Config.load();

		// 2. Enregistrer (déclarer) tous les sous-mods existants dans notre API
		registerModules();

		// 3. Boucle magique : On parcourt tous les mods de la liste
		for (MJ_SubMod module : MODULES) {
			if (module.isEnabled()) {
				module.onInit(); // Lance le onInit() du sous-mod uniquement s'il est sur true !
			}
		}
	}

	private void registerModules() {
		// C'est ici que tu ajoutes tes sous-mods au catalogue au fur et à mesure de ton développement
		MODULES.add(new com.diabloxmj.mod.mj_xpbottle.MJ_XPBottle_Enter());
		// MODULES.add(new com.diabloxmj.monmod.mods.magie.Enter()); // Exemple pour le futur
	}

	public static List<MJ_SubMod> getModules() {
		return MODULES;
	}
	public static Identifier id(String path) {
		return Identifier.of(MOD_ID, path);
	}
}