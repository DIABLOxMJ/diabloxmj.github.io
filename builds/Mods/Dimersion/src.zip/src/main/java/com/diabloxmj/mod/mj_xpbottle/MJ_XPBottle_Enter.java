package com.diabloxmj.mod.mj_xpbottle;


import com.diabloxmj.core.Dimersion_Config;
import com.diabloxmj.core.api.MJ_SubMod;
import com.diabloxmj.mod.mj_xpbottle.network.MJ_XPBottle_Sync_Payload; // Importe la structure de notre paquet réseau personnalisé
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry; // Importe le registre réseau pour déclarer nos paquets
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents; // Importe les déclencheurs (events) de connexion réseau

// Notre point d'entrée spécifique pour l'XP Bank
public class MJ_XPBottle_Enter implements MJ_SubMod {

    @Override
    public boolean isEnabled() {
        // Interroge ta configuration globale. Tout est à false par défaut.
        return Dimersion_Config.INSTANCE.enable_xpbottle;
    }

    @Override
    public void onInit() {
        MJ_XPBottle_Config.load(); // Déclenche la lecture et le chargement du fichier de configuration JSON
        MJ_XPBottle_Item_Mod.registerModItems(); // Déclenche l'enregistrement de l'intégralité de nos fioles d'XP
        MJ_XPBottle_Event.registerEvents(); // Déclenche l'écoute de nos événements personnalisés

        // Enregistre officiellement notre paquet "ConfigSyncPayload" dans le registre réseau de type S2C (Server-To-Client)
        PayloadTypeRegistry.playS2C().register(com.diabloxmj.mod.mj_xpbottle.network.MJ_XPBottle_Sync_Payload.ID, MJ_XPBottle_Sync_Payload.CODEC);

        // Événement s'activant dès qu'un joueur passe l'étape de connexion et apparaît physiquement dans le monde
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            // Le serveur crée une enveloppe réseau (Payload) contenant toutes ses propres valeurs de capacité maximale
            MJ_XPBottle_Sync_Payload payload = new MJ_XPBottle_Sync_Payload(
                    MJ_XPBottle_Config.INSTANCE.XPBottle_lvl1_Max_Capacity,
                    MJ_XPBottle_Config.INSTANCE.XPBottle_lvl2_Max_Capacity,
                    MJ_XPBottle_Config.INSTANCE.XPBottle_lvl3_Max_Capacity,
                    MJ_XPBottle_Config.INSTANCE.XPBottle_lvl4_Max_Capacity,
                    MJ_XPBottle_Config.INSTANCE.XPBottle_lvl5_Max_Capacity,
                    MJ_XPBottle_Config.INSTANCE.XPBottle_lvl6_Max_Capacity
            );
            // Le serveur expédie l'enveloppe sur le réseau à destination unique du joueur qui vient d'entrer
            sender.sendPacket(payload);
        });
    }

    @Override
    public void onClientInit() {
        // Laisser vide. C'est Dimersion_Client dans le dossier client qui s'en chargera globalement.
    }
}